import * as React from 'react';

const DashboardSidebarContext = React.createContext(null);

export default DashboardSidebarContext;
