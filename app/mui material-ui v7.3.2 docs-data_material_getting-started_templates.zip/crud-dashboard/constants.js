export const DRAWER_WIDTH = 240; // px
export const MINI_DRAWER_WIDTH = 90; // px
