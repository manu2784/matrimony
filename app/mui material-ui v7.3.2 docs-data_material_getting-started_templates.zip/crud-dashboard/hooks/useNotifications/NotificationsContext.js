import * as React from 'react';

const NotificationsContext = React.createContext(null);

export default NotificationsContext;
