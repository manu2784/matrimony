import * as React from 'react';

const DialogsContext = React.createContext(null);

export default DialogsContext;
